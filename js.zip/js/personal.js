function toggleMenu() {
    const menu = document.querySelector('.personal-burger');
    menu.classList.toggle('personal-burger__menu');
}
