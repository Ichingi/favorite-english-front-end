const passwordEditIcon = document.querySelector('.password-edit');
const userDataContent = document.querySelector('.user-data__content');

passwordEditIcon.addEventListener('click', function () {
    let confirmPasswordField = document.querySelector('.confirm-password');
    
    // Если поле уже существует (повторное нажатие)
    if (confirmPasswordField) {
        confirmPasswordField.style.maxHeight = '0'; // Скрываем поле с анимацией
        confirmPasswordField.style.opacity = '0'; // Плавное исчезновение
        setTimeout(() => {
            confirmPasswordField.remove(); // Удаляем элемент через таймер, чтобы завершилась анимация
        }, 300); // Время должно совпадать с CSS-анимацией
    } else {
        // Если поле еще не существует
        confirmPasswordField = document.createElement('div');
        confirmPasswordField.className = 'user-data__password confirm-password';
        confirmPasswordField.style.transition = 'max-height 0.3s ease-out, opacity 0.3s ease-out';
        confirmPasswordField.style.maxHeight = '0';
        confirmPasswordField.style.opacity = '0';
        confirmPasswordField.style.overflow = 'hidden';

        confirmPasswordField.innerHTML = `
            <img src="../images/password.svg" class="password-icon" alt="Password">
            <input type="password" id="confirmPassword" placeholder="Подтвердите пароль" disabled>
            <ion-icon name="eye-outline" class="toggle-confirm-password"></ion-icon>
        `;
        userDataContent.appendChild(confirmPasswordField);

        // Активация поля и иконки через небольшую задержку (для анимации)
        setTimeout(() => {
            confirmPasswordField.style.maxHeight = '50px';
            confirmPasswordField.style.opacity = '1';
            const confirmPasswordInput = document.getElementById('confirmPassword');
            confirmPasswordInput.disabled = false; // Убираем disabled
        }, 10);
    }
});
